<?php

namespace App\Http\Controllers;

use App\Models\AccountCode;
use App\Models\AccountGroup;
use Illuminate\Http\Request;
use App\Models\AccountType;
use App\Models\GolonganAkun;
use App\Utilities\DataUtility;
use Illuminate\Support\Facades\DB;

class AccountTypesController extends Controller
{
    use DataUtility;

    public function index()
    {
        return view('backend.account_types.index');
    }

    public function getAccountTypeData(Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');

        $searchColumns = ['account_types.type_akun'];

        $format = [
            'id' => 'id',
            'account_groups_id' => function ($type) {
                return '<a href="' . route('account-types.edit', $type->id) . '">' . ($type->golonganAkun ? $type->golonganAkun->accountGroup->kode_kelompok . $type->golonganAkun->kode_golongan . ' - ' . $type->golonganAkun->nama_golongan : '') . '</a>';
            },            
            'type_akun' => function ($type) {
                return '<a href="' . route('account-types.edit', $type->id) . '">' . ($type->golonganAkun ? $type->golonganAkun->accountGroup->kode_kelompok . $type->golonganAkun->kode_golongan : '').$type->kode_type . ' - ' .$type->type_akun . '</a>';
            },
            'saldo_normal' => function ($type) {
                return $type->saldo_normal === 'Db' ? 'Debet' : 'Kredit';
            },
            'posisi' => function ($type) {
                return $type->posisi === 'NRC' ? 'Neraca' : 'Laporan Laba Rugi';
            },
            'action' => function ($type) {
                return $this->simpleButtons($type, 'account-types.destroy');
            },
        ];

        $data = $this->getData($request, AccountType::class, $start, $length, $search, $searchColumns, $format);

        $data['draw'] = $draw;

        return response()->json($data);
    }
    
    public function create()
    {
        $accountGroups = GolonganAkun::get();
        return view('backend.account_types.create', compact('accountGroups'));
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'golongan_akun_id' => 'required',
            'type_akun' => 'required|unique:account_types',
            'saldo_normal' => 'required',
            'posisi' => 'required',
        ]);

        $existingType = AccountType::where('golongan_akun_id', $request->golongan_akun_id)
            ->where('kode_type', $request->kode_type)
            ->exists();

        if ($existingType) {
            return response()->json(['success' => false, 'message' => 'Golongan Akun dan Kode Tipe sudah digunakan'], 422);
        }

        DB::beginTransaction();
        try {
            $dataAdd = AccountType::create($request->all());

            if ($request->has('duplicate_accounts') && $request->input('duplicate_accounts') == true) {
                $accountGolongan = GolonganAkun::find($request->golongan_akun_id);
                $accountGroup = AccountGroup::find($accountGolongan->account_groups_id);
                
                if ($accountGroup && $accountGolongan) {
                    $code = $accountGroup->kode_kelompok . $accountGolongan->kode_golongan . $request->kode_type . "000";
        
                    $existingAccountCode = AccountCode::where('code', $code)->first();
        
                    if ($existingAccountCode) {
                        $existingAccountCode->update(['description' => $request->input('type_akun')]);
                    } else {
                        AccountCode::create([
                            'code' => $code,
                            'description' => $request->input('type_akun'),
                            'account_group_id' => $accountGroup->id,
                            'account_type_id' => $dataAdd->id,
                            'golongan_akun_id' => $accountGolongan->id,
                        ]);
                    }
                } else {
                    return response()->json(['success' => false, 'message' => 'Kelompok dan Golongan Akun tidak ditemukan'], 442);
                }
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Tipe Akun berhasil ditambahkan']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => 'Tipe akun gagal ditambahkan']);
        }
    }

    public function edit(AccountType $accountType)
    {
        $accountGroups = GolonganAkun::get();
        return view('backend.account_types.edit', compact('accountType', 'accountGroups'));
    }

    public function update(Request $request, AccountType $accountType)
    {
        $request->validate([
            'golongan_akun_id' => 'required',
            'type_akun' => 'required|unique:account_types,type_akun,' . $accountType->id,
            'saldo_normal' => 'required',
            'posisi' => 'required',
        ]);

        // Memeriksa apakah kombinasi golongan_akun_id dan kode_type sudah ada
        $existingType = AccountType::where('golongan_akun_id', $request->golongan_akun_id)
            ->where('kode_type', $request->kode_type)
            ->where('id', '!=', $accountType->id)
            ->exists();

        if ($existingType) {
            return response()->json(['success' => false, 'message' => 'Golongan Akun dan dan Kode Tipe sudah digunakan'], 422);
        }

        DB::beginTransaction();
        try {
            if ($request->has('duplicate_accounts') && $request->input('duplicate_accounts') == true) {
                $accountGolongan = GolonganAkun::find($request->golongan_akun_id);
                $accountGroup = AccountGroup::find($accountGolongan->account_groups_id);
                
                if ($accountGroup && $accountGolongan) {
                    $code = $accountGroup->kode_kelompok . $accountGolongan->kode_golongan . $request->kode_type . "000";
        
                    $existingAccountCode = AccountCode::where('code', $code)->first();
        
                    if ($existingAccountCode) {
                        $existingAccountCode->update(['description' => $request->input('type_akun')]);
                    } else {
                        AccountCode::create([
                            'code' => $code,
                            'description' => $request->input('type_akun'),
                            'account_group_id' => $accountGroup->id,
                            'account_type_id' => $accountType->id,
                            'golongan_akun_id' => $accountGolongan->id,
                        ]);
                    }
                } else {
                    return response()->json(['success' => false, 'message' => 'Kelompok dan Golongan Akun tidak ditemukan'], 442);
                }
            }

            $accountType->update($request->all());
            DB::commit();
            return response()->json(['success' => true, 'message' => 'Tipe Akun berhasil di Update']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => 'Tipe Akun gagal di Update'. $e->getMessage()]);
        }
    }

    public function destroy(AccountType $accountType)
    {
        try {
            $accountType->delete();
            return response()->json(['message' => 'Tipe Akun berhasil dihapus.'], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Terjadi kesalahan pada sistem'], 500);
        }
    }

}
