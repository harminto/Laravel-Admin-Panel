<?php

namespace App\Http\Controllers;

use App\Models\AccountCode;
use App\Models\AccountGroup;
use Illuminate\Http\Request;
use App\Models\GolonganAkun;
use App\Utilities\DataUtility;
use Illuminate\Support\Facades\DB;

class GolonganAkunController extends Controller
{
    use DataUtility;

    public function index()
    {
        return view('backend.golongan_akuns.index');
    }

    public function getGolonganAkunData(Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');

        $searchColumns = ['golongan_akuns.nama_golongan'];

        $format = [
            'id' => 'id',
            'account_groups_id' => function ($golongan) {
                return '<a href="' . route('golongan-akun.edit', $golongan->id) . '">' . $golongan->accountGroup->kode_kelompok . ' - ' . $golongan->accountGroup->name . '</a>';
            },
            'nama_golongan' => function ($golongan) {
                return '<a href="' . route('golongan-akun.edit', $golongan->id) . '">' . $golongan->accountGroup->kode_kelompok . $golongan->kode_golongan . ' - ' . $golongan->nama_golongan . '</a>';
            },
            'keterangan' => 'keterangan',
            'action' => function ($golongan) {
                return $this->simpleButtons($golongan, 'golongan-akun.destroy');
            },
        ];

        $data = $this->getData($request, GolonganAkun::class, $start, $length, $search, $searchColumns, $format);

        $data['draw'] = $draw;

        return response()->json($data);
    }

    public function create()
    {
        $accountGroups = AccountGroup::all();
        return view('backend.golongan_akuns.create', compact('accountGroups'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'nama_golongan' => 'required|unique:golongan_akuns',
        ]);

        if ($request->has('kode_golongan')) {
            $existingGolongan = GolonganAkun::where('kode_golongan', $request->kode_golongan)->first();
    
            if ($existingGolongan) {
                return response()->json(['success' => false, 'message' => 'Kode Golongan sudah ada'], 422);
            }
        }

        DB::beginTransaction();
        try {
            $dataAdd = GolonganAkun::create($request->all());

            if ($request->has('duplicate_accounts') && $request->input('duplicate_accounts') == true) {
                $accountGroup = AccountGroup::find($request->account_groups_id);
                
                if ($accountGroup) {
                    $code = $accountGroup->kode_kelompok . $request->kode_golongan . "0000";
        
                    $existingAccountCode = AccountCode::where('code', $code)->first();
        
                    if ($existingAccountCode) {
                        $existingAccountCode->update(['description' => $request->input('nama_golongan')]);
                    } else {
                        AccountCode::create([
                            'code' => $code,
                            'description' => $request->input('nama_golongan'),
                            'account_group_id' => $request->account_groups_id,
                            'account_type_id' => null,
                            'golongan_akun_id' => $dataAdd->id,
                        ]);
                    }
                } else {
                    return response()->json(['success' => false, 'message' => 'Group Akun tidak ditemukan'], 442);
                }
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Golongan akun berhasil disimpan']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => 'Gagal menambahkan golongan akun']);
        }
    }

    public function edit(GolonganAkun $golonganAkun)
    {
        $accountGroups = AccountGroup::all();
        return view('backend.golongan_akuns.edit', compact('golonganAkun','accountGroups'));
    }

    public function update(Request $request, GolonganAkun $golonganAkun)
    {
        $request->validate([
            'nama_golongan' => 'required|unique:golongan_akuns,nama_golongan,' . $golonganAkun->id,
        ]);

        if ($request->has('kode_golongan')) {
            $existingGolonganAkun = GolonganAkun::where('kode_golongan', $request->kode_golongan)
                ->where('id', '!=', $golonganAkun->id)
                ->first();
    
            if ($existingGolonganAkun) {
                return response()->json(['success' => false, 'message' => 'Kode Golongan sudah ada'], 422);
            }
        }
        
        DB::beginTransaction();
        try {
            if ($request->has('duplicate_accounts') && $request->input('duplicate_accounts') == true) {
                $accountGroup = AccountGroup::find($request->account_groups_id);
                
                if ($accountGroup) {
                    $code = $accountGroup->kode_kelompok . $request->kode_golongan . "0000";
        
                    $existingAccountCode = AccountCode::where('code', $code)->first();
        
                    if ($existingAccountCode) {
                        $existingAccountCode->update(['description' => $request->input('nama_golongan')]);
                    } else {
                        AccountCode::create([
                            'code' => $code,
                            'description' => $request->input('nama_golongan'),
                            'account_group_id' => $request->account_groups_id,
                            'account_type_id' => null,
                            'golongan_akun_id' => $golonganAkun->id,
                        ]);
                    }
                } else {
                    return response()->json(['success' => false, 'message' => 'Group Akun tidak ditemukan'], 442);
                }
            }

            $golonganAkun->update($request->all());
            DB::commit();
            return response()->json(['success' => true, 'message' => 'Golongan berhasil diperbaharui']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => 'Gagal memperbaharui golongan akun' . $e->getMessage()]);
        }
    }

    public function destroy(GolonganAkun $golonganAkun)
    {
        try {
            $golonganAkun->delete();
            return response()->json(['message' => 'Golongan akun berhasil dihapus.'], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Terjadi kesalahan pada sistem'], 500);
        }
    }
}
