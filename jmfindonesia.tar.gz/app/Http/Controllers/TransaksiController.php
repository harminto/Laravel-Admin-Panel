<?php

namespace App\Http\Controllers;

use App\Models\AccountCode;
use App\Models\Transaksi;
use App\Models\TransaksiDetail;
use Illuminate\Http\Request;
use App\Utilities\DataUtility;
use Illuminate\Support\Facades\DB;

class TransaksiController extends Controller
{
    use DataUtility;

    public function index()
    {
        $transaksis = Transaksi::with('transaksiDetails')->paginate(50);
        return view('backend.transactions.index', compact('transaksis'));
    }

    public function create()
    {
        $accounts = AccountCode::all(); // Ambil semua data akun dari basis data

        return view('backend.transactions.create', compact('accounts'));
    }

    public function store(Request $request)
    {
        try {
            $request->validate([
                'tanggal' => 'required|date',
                'deskripsi' => 'required|string',
                'ref' => 'required|string',
                //'total' => 'required|numeric',
                'account_code_id' => 'required|array',
                'jenis_transaksi' => 'required|array',
                'jumlah' => 'required|array',
            ]);

            DB::beginTransaction();
            $transaksi = Transaksi::create([
                'tanggal' => $request->tanggal,
                'deskripsi' => $request->deskripsi,
                'ref' => $request->ref,
                //'total' => $request->total,
            ]);

            // Simpan detail transaksi
            $accountCodes = $request->input('account_code_id');
            $debitCredits = $request->input('jenis_transaksi');
            $amounts = $request->input('jumlah');

            foreach ($accountCodes as $key => $accountCode) {
                TransaksiDetail::create([
                    'transaksi_id' => $transaksi->id,
                    'account_code_id' => $accountCode,
                    'jenis_transaksi' => $debitCredits[$key],
                    'jumlah' => $amounts[$key],
                ]);
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Data transaksi berhasil disimpan'], 200);
        } catch (\Exception $e) {
            DB::rollback();
            // Tangkap dan kembalikan pesan error
            return response()->json(['success' => false, 'message' => 'Gagal menyimpan data transaksi: ' . $e->getMessage()], 500);
        }
    }

    /* public function getTransactionData(Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');

        $query = Transaksi::query();

        // Pencarian
        if (!empty($search)) {
            $query->where('tanggal', 'LIKE', "%$search%")
                ->orWhere('deskripsi', 'LIKE', "%$search%")
                ->orWhere('ref', 'LIKE', "%$search%")
                ->orWhere('total', 'LIKE', "%$search%");
        }

        // Pengurutan (contoh pengurutan berdasarkan tanggal secara default)
        $query->orderBy('tanggal', 'desc');

        // Pembagian Halaman
        $totalData = $query->count();
        $transaksis = $query->offset($start)->limit($length)->get();

        $data = [];
        foreach ($transaksis as $transaksi) {
            foreach ($transaksi->transaksiDetails as $detail) {
                $rowData = [
                    'tanggal' => $transaksi->tanggal,
                    'ref' => $transaksi->ref,
                    'deskripsi' => $transaksi->deskripsi,
                    'akun_id' => $detail->akun_id,
                    'jenis_transaksi' => $detail->jenis_transaksi,
                    'jumlah' => $detail->jumlah,
                ];

                $data[] = $rowData;
            }
        }

        return response()->json([
            'draw' => $draw,
            'recordsTotal' => $totalData,
            'recordsFiltered' => $totalData,
            'data' => $data,
        ]);
    }

    public function show($id)
    {
        // Logika untuk menampilkan detail transaksi dengan ID tertentu
    } */
}
