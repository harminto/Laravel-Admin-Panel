<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AccountCode;
use App\Models\AccountGroup;
use App\Models\AccountType;
use App\Models\GolonganAkun;
use App\Utilities\DataUtility;

class AccountCodesController extends Controller
{
    use DataUtility;

    public function index()
    {
        $akunGroups = AccountGroup::get();

        return view('backend.account_codes.index', compact('akunGroups'));
    }

    public function getAccountCodeData(Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');

        $searchColumns = ['account_codes.code', 'account_codes.description'];

        $format = [
            'id' => 'id',
            'code' => function ($code) {
                $paddedCode = str_pad($code->code, 6, '0', STR_PAD_LEFT);
    
                // Memisahkan kode menjadi blok tiga digit yang dipisahkan oleh titik
                $formattedCode = chunk_split($paddedCode, 3, '.');
                
                // Menghapus karakter tambahan di ujung kanan
                $formattedCode = rtrim($formattedCode, '.');
                
                return '<a href="' . route('account-codes.edit', $code->id) . '">' . $formattedCode . '</a>';
            },
            'description' => function ($code) {
                return '<a href="' . route('account-codes.edit', $code->id) . '">' . $code->description . '</a>';
            },
            'account_group_id' => function ($code) {
                return $code->accountGroup ? $code->accountGroup->name : null;
            },
            'account_type_id' => function ($code) {
                return $code->accountType ? $code->accountType->type_akun : null;
            },
            'action' => function ($code) {
                return $this->simpleButtons($code, 'account-codes.destroy');
            },
        ];

        $data = $this->getDataWithOrder($request, AccountCode::class, $start, $length, $search, $searchColumns, $format, 'code');

        $data['draw'] = $draw;

        return response()->json($data);
    }

    public function getDataByGroup($groupId, Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');

        $searchColumns = ['account_codes.code', 'account_codes.description'];

        $format = [
            'id' => 'id',
            'code' => function ($code) {
                $paddedCode = str_pad($code->code, 6, '0', STR_PAD_LEFT);
    
                // Memisahkan kode menjadi blok tiga digit yang dipisahkan oleh titik
                $formattedCode = chunk_split($paddedCode, 3, '.');
                
                // Menghapus karakter tambahan di ujung kanan
                $formattedCode = rtrim($formattedCode, '.');
                
                return '<a href="' . route('account-codes.edit', $code->id) . '">' . $formattedCode . '</a>';
            },
            'description' => function ($code) {
                return '<a href="' . route('account-codes.edit', $code->id) . '">' . $code->description . '</a>';
            },
            'account_group_id' => function ($code) {
                return $code->accountGroup ? $code->accountGroup->name : null;
            },
            'account_type_id' => function ($code) {
                return $code->accountType ? $code->accountType->type_akun : null;
            },
            'action' => function ($code) {
                return $this->simpleButtons($code, 'account-codes.destroy');
            },
        ];

        // Mengambil data dari model AccountCode dengan account_group_id yang sesuai
        $data = $this->getDataWithCondition($request, AccountCode::class, ['account_group_id' => $groupId], $start, $length, $search, $searchColumns, $format, 'code');

        $data['draw'] = $draw;

        return response()->json($data);
    }

    public function create()
    {
        $accountGroups = AccountGroup::all();
        $accountTypes = AccountType::all();

        return view('backend.account_codes.create', compact('accountGroups', 'accountTypes'));
    }
    
    public function store(Request $request)
    {
        $request->validate([
            'head_code' => 'required',
            'code' => 'required|unique:account_codes',
            'description' => 'required',
            'account_group_id' => 'required|exists:account_groups,id',
            'account_type_id' => 'required|exists:account_types,id',
            'golongan_akun_id' => 'required|exists:golongan_akuns,id',
        ]);

        try {
            $combinedCode = $request->input('head_code') . $request->input('code');

            // Membuat array data untuk disimpan ke database
            $data = [
                'code' => $combinedCode,
                'description' => $request->input('description'),
                'account_group_id' => $request->input('account_group_id'),
                'account_type_id' => $request->input('account_type_id'),
            ];

            // Membuat record baru di database
            AccountCode::create($data);
            return response()->json(['success' => true, 'message' => 'Akun Perkiraan berhasil ditambahkan']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Akun Perkiraan gagal ditambahkan']);
        }
    }

    public function edit(AccountCode $accountCode)
    {
        $accountGroups = AccountGroup::all();
        $accountTypes = AccountType::all();
        $golonganAkuns = GolonganAkun::all();
        return view('backend.account_codes.edit', compact('accountCode', 'accountGroups', 'accountTypes', 'golonganAkuns'));
    }

    public function update(Request $request, AccountCode $accountCode)
    {
        $request->validate([
            'code' => 'required|unique:account_codes,code,' . $accountCode->id,
            'description' => 'required',
            'account_group_id' => 'required|exists:account_groups,id',
            'account_type_id' => 'required|exists:account_types,id',
            'golongan_akun_id' => 'required|exists:golongan_akuns,id',
        ]);
    
        try {
            $combinedCode = $request->input('head_code') . $request->input('code');
    
            // Membuat array data untuk disimpan ke database
            $data = [
                'code' => $combinedCode,
                'description' => $request->input('description'),
                'account_group_id' => $request->input('account_group_id'),
                'account_type_id' => $request->input('account_type_id'),
            ];
    
            $accountCode->update($data);
            return response()->json(['success' => true, 'message' => 'Akun Perkiraan berhasil di ubah']);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => 'Akun Perkiraan gagal diubah']);
        }
    }

    public function destroy(AccountCode $accountCode)
    {
        try {
            $accountCode->delete();
            return response()->json(['message' => 'Akun Perkiraan berhasil dihapus'], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Terjadi kesalahan pada sistem'], 500);
        }
    }

    public function getGolonganAkun($account_group_id)
    {
        $golonganAkun = GolonganAkun::with('accountGroup')->where('account_groups_id', $account_group_id)->get();
        return response()->json($golonganAkun);
    }

    public function getAccountType($golongan_akun_id)
    {
        $accountType = AccountType::with('golonganAkun.accountGroup')->where('golongan_akun_id', $golongan_akun_id)->get();
        return response()->json($accountType);
    }
}
