<?php

namespace App\Http\Controllers;

use App\Models\AccountCode;
use Illuminate\Http\Request;
use App\Models\AccountGroup;
use App\Utilities\DataUtility;
use Illuminate\Support\Facades\DB;

class AccountGroupsController extends Controller
{
    use DataUtility;

    public function index()
    {
        return view('backend.account_groups.index');
    }

    public function getAccountGroupData(Request $request)
    {
        $draw = $request->input('draw');
        $start = $request->input('start');
        $length = $request->input('length');
        $search = $request->input('search.value');

        $searchColumns = ['account_groups.name'];

        $format = [
            'id' => 'id',
            'kode_kelompok' => function ($group) {
                return '<a href="' . route('account-groups.edit', $group->id) . '">' . $group->kode_kelompok . '</a>';
            },
            'name' => function ($group) {
                return '<a href="' . route('account-groups.edit', $group->id) . '">' . $group->name . '</a>';
            },
            'action' => function ($group) {
                return $this->simpleButtons($group, 'account-groups.destroy');
            },
        ];

        $data = $this->getData($request, AccountGroup::class, $start, $length, $search, $searchColumns, $format);

        $data['draw'] = $draw;

        return response()->json($data);
    }

    public function create()
    {
        return view('backend.account_groups.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:account_groups',
        ]);
    
        // Validasi manual untuk kode_kelompok
        if ($request->has('kode_kelompok')) {
            $existingGroup = AccountGroup::where('kode_kelompok', $request->kode_kelompok)->first();
    
            if ($existingGroup) {
                return response()->json(['success' => false, 'message' => 'Kode Kelompok sudah ada']);
            }
        }

        DB::beginTransaction();

        try {
            $addData = AccountGroup::create($request->all());

            // Cek apakah checkbox di-centang
            if ($request->has('duplicate_accounts') && $request->input('duplicate_accounts') == true) {
                // Buat kode untuk AccountCode
                $code = $request->kode_kelompok . "00000";

                // Cek apakah kode sudah ada dalam database
                $existingAccountCode = AccountCode::where('code', $code)->first();

                if ($existingAccountCode) {
                    // Jika kode sudah ada, update description
                    $existingAccountCode->update(['description' => $request->input('name')]);
                } else {
                    // Jika kode belum ada, buat entri baru di AccountCode
                    AccountCode::create([
                        'code' => $code,
                        'description' => $request->input('name'),
                        'account_group_id' => $addData->id,
                        'account_type_id' => null,
                        'golongan_akun_id' => null,
                    ]);
                }
            }

            DB::commit();
            return response()->json(['success' => true, 'message' => 'Account group created successfully']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => 'Failed to create account group']);
        }
    }

    public function edit(AccountGroup $accountGroup)
    {
        return view('backend.account_groups.edit', compact('accountGroup'));
    }

    public function update(Request $request, AccountGroup $accountGroup)
    {
        $request->validate([
            'name' => 'required|unique:account_groups,name,' . $accountGroup->id,
        ]);
    
        // Validasi manual untuk kode_kelompok
        if ($request->has('kode_kelompok')) {
            $existingGroup = AccountGroup::where('kode_kelompok', $request->kode_kelompok)
                ->where('id', '!=', $accountGroup->id)
                ->first();
    
            if ($existingGroup) {
                return response()->json(['success' => false, 'message' => 'Kode Kelompok sudah ada'], 422);
            }
        }
        
        DB::beginTransaction();

        try {
            // Cek apakah checkbox di-centang
            if ($request->has('duplicate_accounts') && $request->input('duplicate_accounts') == true) {
                // Buat kode untuk AccountCode
                $code = $request->kode_kelompok . "00000";

                // Cek apakah kode sudah ada dalam database
                $existingAccountCode = AccountCode::where('code', $code)->first();

                if ($existingAccountCode) {
                    // Jika kode sudah ada, update description
                    $existingAccountCode->update(['description' => $request->input('name')]);
                } else {
                    // Jika kode belum ada, buat entri baru di AccountCode
                    AccountCode::create([
                        'code' => $code,
                        'description' => $request->input('name'),
                        'account_group_id' => $accountGroup->id,
                        'account_type_id' => null,
                        'golongan_akun_id' => null,
                    ]);
                }
            }
            $accountGroup->update($request->all());
            DB::commit();
            return response()->json(['success' => true, 'message' => 'Account group updated successfully']);
        } catch (\Exception $e) {
            DB::rollback();
            return response()->json(['success' => false, 'message' => 'Failed to update account group']);
        }
    }

    public function destroy(AccountGroup $accountGroup)
    {
        try {
            $accountGroup->delete();
            return response()->json(['message' => 'Account group deleted successfully.'], 200);
        } catch (\Exception $e) {
            return response()->json(['message' => 'An error occurred.'], 500);
        }
    }

}
