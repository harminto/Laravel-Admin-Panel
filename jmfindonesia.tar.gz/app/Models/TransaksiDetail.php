<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TransaksiDetail extends Model
{
    use HasFactory;

    protected $fillable = ['transaksi_id', 'account_code_id', 'jenis_transaksi', 'jumlah'];

    public function transaksi()
    {
        return $this->belongsTo(Transaksi::class);
    }

    public function accountCode()
    {
        return $this->belongsTo(AccountCode::class);
    }
}
