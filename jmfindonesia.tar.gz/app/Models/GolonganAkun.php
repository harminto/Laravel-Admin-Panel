<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GolonganAkun extends Model
{
    use HasFactory;

    protected $table = 'golongan_akuns';

    protected $fillable = [
        'account_groups_id',
        'kode_golongan',
        'nama_golongan',
        'keterangan',
    ];

    public function accountGroup()
    {
        return $this->belongsTo(AccountGroup::class, 'account_groups_id');
    }
}
