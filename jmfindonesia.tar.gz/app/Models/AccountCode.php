<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccountCode extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'description',
        'account_group_id',
        'account_type_id',
        'golongan_akun_id',
    ];

    public function accountGroup()
    {
        return $this->belongsTo(AccountGroup::class);
    }

    public function accountType()
    {
        return $this->belongsTo(AccountType::class);
    }

    public function golonganAkun()
    {
        return $this->belongsTo(GolonganAkun::class);
    }

}
