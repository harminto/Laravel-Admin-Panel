<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccountType extends Model
{
    use HasFactory;

    protected $fillable = [
        'golongan_akun_id',
        'kode_type',
        'type_akun',
        'saldo_normal',
        'posisi',
    ];

    public function golonganAkun()
    {
        return $this->belongsTo(GolonganAkun::class, 'golongan_akun_id');
    }
}
