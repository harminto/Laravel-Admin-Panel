<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAccountTypesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('account_types', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('golongan_akun_id');
            $table->string('kode_type');
            $table->string('type_akun');
            $table->enum('saldo_normal', ['Db', 'Kr']);
            $table->enum('posisi', ['NRC', 'LR']);
            $table->timestamps();

            $table->foreign('golongan_akun_id')->references('id')->on('golongan_akuns')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('account_types');
    }
}
